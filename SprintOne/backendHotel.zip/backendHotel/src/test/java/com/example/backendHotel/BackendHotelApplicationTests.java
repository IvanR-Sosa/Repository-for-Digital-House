package com.example.backendHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
